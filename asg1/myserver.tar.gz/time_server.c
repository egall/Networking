/*
 * Erik Steggall
 * CMPS 156
 * 01/25/12
 * Assignement #1
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <strings.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define MAXLINE 128
#define BACKLOG 1

int main(int argc, char **argv){
    int itor;
    int listenfd, connfd;
    struct sockaddr_in server_addr;
    struct sockaddr_in client_addr;
    int addr_len, numbytes;
    char buff[MAXLINE];
    time_t ticks;
    char * port_str;
    int port_num;
    
    port_num = atoi(argv[1]);
    printf("Port Num = %d\n", port_num);

    listenfd = socket(AF_INET, SOCK_STREAM, 0);

    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    server_addr.sin_port = htons(port_num);

    bind(listenfd, (struct sockaddr *) &server_addr, sizeof(struct sockaddr));

    listen(listenfd, BACKLOG);
    printf("Before loop\n");

    for(;;){
        printf("looping...\n");
        connfd = accept(listenfd, (struct sockaddr *) NULL, NULL);

        ticks = time(NULL);
        snprintf(buff, sizeof(buff), "%.24s\r\n",ctime(&ticks));
        write(connfd, buff, strlen(buff));

        close(connfd);
    }
}
